package camoweed.rosesword;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import turniplabs.halplibe.HalpLibe;
import turniplabs.halplibe.util.ClientStartEntrypoint;
import turniplabs.halplibe.util.GameStartEntrypoint;
import turniplabs.halplibe.util.RecipeEntrypoint;


public class ModMain implements ModInitializer, RecipeEntrypoint, GameStartEntrypoint {
	public static final String MOD_ID = HalpLibe.registerMod("rosesword", true);
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    @Override
    public void onInitialize() {
		ModItems.initItems();
		OreTags.init();
		OreGroups.init();
		PickAxeRegister.init();
		PickAxeRegister.register(ModItems.rosePick);
        LOGGER.info("Rosesword initialized.");
    }

	@Override
	public void onRecipesReady() {

	}

	@Override
	public void initNamespaces() {

	}

	@Override
	public void beforeGameStart() {

	}

	@Override
	public void afterGameStart() {

	}
}
