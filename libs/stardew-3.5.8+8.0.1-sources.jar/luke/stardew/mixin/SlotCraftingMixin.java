package luke.stardew.mixin;

import luke.stardew.achievements.StardewAchievements;
import luke.stardew.blocks.StardewBlocks;
import net.minecraft.core.entity.player.Player;
import net.minecraft.core.item.ItemStack;
import net.minecraft.core.player.inventory.slot.SlotResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = SlotResult.class, remap = false)
public abstract class SlotCraftingMixin {
    @Shadow
    private Player thePlayer;

    @Inject(method = "onTake", at = @At(value = "INVOKE", target = "Lnet/minecraft/core/item/ItemStack;onCrafting(Lnet/minecraft/core/world/World;Lnet/minecraft/core/entity/player/Player;)V", shift = At.Shift.AFTER))
    public void addCraftingAchievements(ItemStack itemStack, CallbackInfo ci) {
        if (itemStack.itemID == StardewBlocks.SAPLING_APPLE_GOLDEN.id()) {
            thePlayer.addStat(StardewAchievements.GAPPLE, 1);
        }
        if (itemStack.itemID == StardewBlocks.CANDLE.id()) {
            thePlayer.addStat(StardewAchievements.CANDLE, 1);
        }
    }
}
