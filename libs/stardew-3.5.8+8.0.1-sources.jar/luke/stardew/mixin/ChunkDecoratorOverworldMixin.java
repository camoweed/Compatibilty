package luke.stardew.mixin;

import com.llamalad7.mixinextras.sugar.Local;
import luke.stardew.world.WorldFeatureBush;
import luke.stardew.world.WorldFeatureCauliflower;
import luke.stardew.world.WorldFeatureMelon;
import net.minecraft.core.world.World;
import net.minecraft.core.world.chunk.Chunk;
import net.minecraft.core.world.generate.chunk.perlin.overworld.ChunkDecoratorOverworld;
import net.minecraft.core.world.pos.TilePos;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(value = ChunkDecoratorOverworld.class, remap = false)
public abstract class ChunkDecoratorOverworldMixin {
    @Shadow
    @Final
    private World world;

    @Inject(method = "decorate", at = @At(value = "INVOKE", target = "Ljava/util/Random;nextInt(I)I", ordinal = 104))
    public void stardewDecorations(Chunk chunk, CallbackInfo ci, @Local(name = "rand") Random rand, @Local(name = "x") int x, @Local(name = "z") int z) {
        var pos = new TilePos(x + rand.nextInt(16) + 8, this.world.getHeightValue(x, z), z + rand.nextInt(16) + 8);

        if (rand.nextInt(64) == 0)
            (new WorldFeatureCauliflower()).place(this.world, rand, pos);

        if (rand.nextInt(64) == 0) {
            (new WorldFeatureMelon()).place(this.world, rand, pos);
        }

        if (rand.nextInt(12) == 0) {
            (new WorldFeatureBush(96)).place(this.world, rand, pos);
        }
    }
}
